(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))s(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const n of r.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(o){if(o.ep)return;o.ep=!0;const r=t(o);fetch(o.href,r)}})();document.addEventListener("DOMContentLoaded",()=>{const i=document.getElementById("app");if(!i)return;const e=document.createElement("div");e.className="wireframe-container",i.appendChild(e);const t=document.createElement("div");t.className="toast",i.appendChild(t),p(e),m(e),u(e),b(e),h(e),f(e),y(e),x(e),k(e),g(e),w(e),S(e),a("login-screen")});function a(i){document.querySelectorAll(".screen").forEach(s=>{s.classList.remove("active")});const t=document.getElementById(i);if(t){t.classList.add("active");const s=document.querySelector(".bottom-nav");if(s){const o=["home-screen","search-results-screen","profile-screen"].includes(i);if(s.classList.toggle("hidden",!o),o){document.querySelectorAll(".nav-item").forEach(c=>c.classList.remove("active"));let n="";i==="home-screen"?n="nav-home":i==="search-results-screen"?n="nav-search":i==="profile-screen"&&(n="nav-profile");const l=document.getElementById(n);l&&l.classList.add("active")}}}}function d(i){const e=document.querySelector(".toast");e&&(e.textContent=i,e.classList.add("active"),setTimeout(()=>{e.classList.remove("active")},3e3))}function p(i){const e=document.createElement("div");e.id="login-screen",e.className="screen",e.innerHTML=`
    <div style="flex: 1; display: flex; flex-direction: column; justify-content: center;">
      <h1 style="text-align: center; margin-bottom: 30px; font-size: 24px;">AFINDLY</h1>

      <div class="input-group">
        <label for="user-id">ID</label>
        <input type="text" id="user-id" placeholder="Enter your ID">
      </div>

      <div class="input-group">
        <label for="password">Password</label>
        <input type="password" id="password" placeholder="Enter your password">
      </div>

      <div class="error-message" id="login-error">Invalid ID or password. Please try again.</div>

      <button id="login-button">Login</button>
    </div>
  `,i.appendChild(e);const t=e.querySelector("#login-button");t==null||t.addEventListener("click",()=>{var r,n;const s=(r=e.querySelector("#user-id"))==null?void 0:r.value,o=(n=e.querySelector("#password"))==null?void 0:n.value;if(s&&o)a("home-screen"),d("Login successful");else{const l=e.querySelector("#login-error");l==null||l.classList.add("active"),setTimeout(()=>{l==null||l.classList.remove("active")},3e3)}})}function m(i){var s,o,r,n,l,c;const e=document.createElement("div");e.id="home-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">AFINDLY</div>
    </div>

    <div class="search-bar">
      <input type="text" placeholder="Search books...">
      <button id="search-button">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
        </svg>
      </button>
    </div>

    <div class="quick-actions">
      <div class="button" id="borrow-button">Borrow Book</div>
      <div class="button" id="return-button">Return Book</div>
      <div class="button" id="profile-button">My Profile</div>
    </div>

    <div class="section-title">Recently Searched</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Dasar Pemrograman Web</div>
        <div class="item-subtitle">Budi Raharjo</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Algoritma & Pemrograman C++</div>
        <div class="item-subtitle">Rinaldi Munir</div>
      </div>
      <span class="badge unavailable">Borrowed</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Pemrograman Android</div>
        <div class="item-subtitle">Aditya Rahman</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="bottom-nav">
      <div class="nav-item active" id="nav-home">
        <span class="nav-icon">🏠</span>
        Home
      </div>
      <div class="nav-item" id="nav-search">
        <span class="nav-icon">🔍</span>
        Search
      </div>
      <div class="nav-item" id="nav-profile">
        <span class="nav-icon">👤</span>
        Profile
      </div>
    </div>
  `,i.appendChild(e),(s=e.querySelector("#search-button"))==null||s.addEventListener("click",()=>{a("search-results-screen")}),(o=e.querySelector("#borrow-button"))==null||o.addEventListener("click",()=>{a("search-results-screen")}),(r=e.querySelector("#return-button"))==null||r.addEventListener("click",()=>{a("return-books-screen")}),(n=e.querySelector("#profile-button"))==null||n.addEventListener("click",()=>{a("profile-screen")}),(l=e.querySelector("#nav-search"))==null||l.addEventListener("click",()=>{a("search-results-screen")}),(c=e.querySelector("#nav-profile"))==null||c.addEventListener("click",()=>{a("profile-screen")}),e.querySelectorAll(".list-item").forEach(v=>{v.addEventListener("click",()=>{a("book-details-screen")})})}function u(i){var s,o,r;const e=document.createElement("div");e.id="search-results-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="search-back">←</span>
      <div class="header-title">Search Results</div>
    </div>

    <div class="search-bar">
      <input type="text" placeholder="Search books..." value="programming">
      <button>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
        </svg>
      </button>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Robert C. Martin</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">The Pragmatic Programmer</div>
        <div class="item-subtitle">Andrew Hunt, David Thomas</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Design Patterns</div>
        <div class="item-subtitle">Erich Gamma, et al.</div>
      </div>
      <span class="badge unavailable">Borrowed</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Refactoring</div>
        <div class="item-subtitle">Martin Fowler</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">JavaScript: The Good Parts</div>
        <div class="item-subtitle">Douglas Crockford</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="bottom-nav">
      <div class="nav-item" id="nav-home-search">
        <span class="nav-icon">🏠</span>
        Home
      </div>
      <div class="nav-item active" id="nav-search-search">
        <span class="nav-icon">🔍</span>
        Search
      </div>
      <div class="nav-item" id="nav-profile-search">
        <span class="nav-icon">👤</span>
        Profile
      </div>
    </div>
  `,i.appendChild(e),(s=e.querySelector("#search-back"))==null||s.addEventListener("click",()=>{a("home-screen")}),(o=e.querySelector("#nav-home-search"))==null||o.addEventListener("click",()=>{a("home-screen")}),(r=e.querySelector("#nav-profile-search"))==null||r.addEventListener("click",()=>{a("profile-screen")}),e.querySelectorAll(".list-item").forEach(n=>{n.addEventListener("click",()=>{a("book-details-screen")})})}function b(i){var t,s;const e=document.createElement("div");e.id="book-details-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="details-back">←</span>
      <div class="header-title">Book Details</div>
    </div>

    <h2 style="margin-bottom: 5px;">Clean Code</h2>
    <p style="color: var(--secondary-color); margin-bottom: 15px;">Robert C. Martin</p>

    <div style="border: 1px solid var(--border-color); width: 120px; height: 180px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: var(--secondary-color);">
      Book Cover
    </div>

    <p style="margin-bottom: 20px;">
      A handbook of agile software craftsmanship that helps programmers write clean, maintainable code.
    </p>

    <div class="section-title">Location</div>
    <p>Floor: 3</p>
    <p>Shelf: CS-101</p>

    <div class="map-container">
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: var(--secondary-color);">
        Floor Map
      </div>
      <div class="map-marker" style="top: 75px; left: 150px;"></div>
    </div>

    <div class="action-buttons">
      <button id="borrow-this-book">Borrow</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#details-back"))==null||t.addEventListener("click",()=>{a("search-results-screen")}),(s=e.querySelector("#borrow-this-book"))==null||s.addEventListener("click",()=>{a("borrow-scan-floor-screen")})}function h(i){var t,s;const e=document.createElement("div");e.id="borrow-scan-floor-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="scan-floor-back">←</span>
      <div class="header-title">Scan Floor QR Code</div>
    </div>

    <div class="scanner-overlay">
      <div class="scanner-frame"></div>
      <div class="scanner-text">Align the QR code for Floor 3 within the frame to verify your location</div>
      <button id="simulate-floor-scan" style="width: auto; margin-top: 20px;">Simulate Successful Scan</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#scan-floor-back"))==null||t.addEventListener("click",()=>{a("book-details-screen")}),(s=e.querySelector("#simulate-floor-scan"))==null||s.addEventListener("click",()=>{a("borrow-navigation-screen")})}function f(i){var t,s;const e=document.createElement("div");e.id="borrow-navigation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="navigation-back">←</span>
      <div class="header-title">Navigate to Book</div>
    </div>

    <div style="text-align: center; margin-bottom: 15px;">
      <h2 style="font-size: 18px; margin-bottom: 5px;">Clean Code</h2>
      <p style="color: var(--secondary-color); font-size: 14px;">Floor: 3, Shelf: CS-101</p>
    </div>

    <div class="map-container">
      <div class="ar-indicator">AR View Active</div>

      <div class="map-3d-view">
        <!-- Floor grid -->
        <div class="map-floor"></div>

        <!-- Walls representing bookshelves -->
        <div class="map-wall horizontal" style="top: 50px; left: 40px;"></div>
        <div class="map-wall horizontal" style="top: 50px; left: 140px;"></div>
        <div class="map-wall horizontal" style="top: 150px; left: 40px;"></div>
        <div class="map-wall horizontal" style="top: 150px; left: 140px;"></div>
        <div class="map-wall horizontal" style="top: 250px; left: 40px;"></div>
        <div class="map-wall horizontal" style="top: 250px; left: 140px;"></div>

        <div class="map-wall vertical" style="top: 70px; left: 40px;"></div>
        <div class="map-wall vertical" style="top: 70px; left: 220px;"></div>
        <div class="map-wall vertical" style="top: 170px; left: 40px;"></div>
        <div class="map-wall vertical" style="top: 170px; left: 220px;"></div>

        <!-- Your current location marker -->
        <div class="map-marker user" style="top: 200px; left: 50px;"></div>

        <!-- Book location marker -->
        <div class="map-marker book" style="top: 75px; left: 180px;"></div>

        <!-- Path between markers -->
        <div class="map-path" style="top: 200px; left: 50px; width: 130px; transform: rotate(-45deg); transform-origin: left;"></div>
        <div class="map-path" style="top: 75px; left: 180px; width: 0; height: 0;"></div>
      </div>
    </div>

    <div style="background-color: var(--surface-color); padding: 15px; border-radius: 10px; margin-top: 15px;">
      <p style="font-weight: 500; margin-bottom: 10px;">Directions:</p>
      <ol style="padding-left: 20px; font-size: 14px; color: var(--secondary-color);">
        <li style="margin-bottom: 8px;">Walk straight ahead past 2 bookshelves</li>
        <li style="margin-bottom: 8px;">Turn right at the Computer Science section</li>
        <li>The book is on the 3rd shelf from the top</li>
      </ol>
    </div>

    <button id="found-book-button" style="margin-top: 15px;">I Found the Book</button>
  `,i.appendChild(e),(t=e.querySelector("#navigation-back"))==null||t.addEventListener("click",()=>{a("borrow-scan-floor-screen")}),(s=e.querySelector("#found-book-button"))==null||s.addEventListener("click",()=>{a("borrow-scan-book-screen")})}function y(i){var t,s;const e=document.createElement("div");e.id="borrow-scan-book-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="scan-book-back">←</span>
      <div class="header-title">Scan Book Barcode</div>
    </div>

    <div class="scanner-overlay">
      <div class="scanner-frame"></div>
      <div class="scanner-text">Align the barcode on the back of the book within the frame to verify</div>
      <button id="simulate-book-scan" style="width: auto; margin-top: 20px;">Simulate Successful Scan</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#scan-book-back"))==null||t.addEventListener("click",()=>{a("borrow-navigation-screen")}),(s=e.querySelector("#simulate-book-scan"))==null||s.addEventListener("click",()=>{a("borrow-confirmation-screen")})}function g(i){var t,s;const e=document.createElement("div");e.id="return-navigation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="return-navigation-back">←</span>
      <div class="header-title">Navigate to Return Shelf</div>
    </div>

    <div style="text-align: center; margin-bottom: 15px;">
      <h2 style="font-size: 18px; margin-bottom: 5px;">Return Book</h2>
      <p style="color: var(--secondary-color); font-size: 14px;">Clean Code by Robert C. Martin</p>
      <p style="color: var(--secondary-color); font-size: 14px;">Go to Return Shelf on Floor 2</p>
    </div>

    <div class="map-container">
      <div class="ar-indicator">AR View Active</div>

      <div class="map-3d-view">
        <!-- Floor grid -->
        <div class="map-floor"></div>

        <!-- Walls representing areas and desks -->
        <div class="map-wall horizontal" style="top: 50px; left: 40px;"></div>
        <div class="map-wall horizontal" style="top: 50px; left: 140px;"></div>
        <div class="map-wall horizontal" style="top: 130px; left: 250px; width: 40px;"></div>
        <div class="map-wall vertical" style="top: 50px; left: 220px;"></div>
        <div class="map-wall vertical" style="top: 140px; left: 40px;"></div>
        <div class="map-wall vertical" style="top: 170px; left: 220px;"></div>

        <!-- Your current location marker -->
        <div class="map-marker user" style="top: 200px; left: 50px;"></div>

        <!-- Return shelf location marker -->
        <div class="map-marker book" style="top: 100px; left: 250px;"></div>

        <!-- Path between markers -->
        <div class="map-path" style="top: 200px; left: 50px; width: 150px; transform: rotate(-45deg); transform-origin: left;"></div>
        <div class="map-path" style="top: 100px; left: 170px; width: 80px;"></div>
      </div>
    </div>

    <div style="background-color: var(--surface-color); padding: 15px; border-radius: 10px; margin-top: 15px;">
      <p style="font-weight: 500; margin-bottom: 10px;">Directions:</p>
      <ol style="padding-left: 20px; font-size: 14px; color: var(--secondary-color);">
        <li style="margin-bottom: 8px;">Walk straight towards the study area</li>
        <li style="margin-bottom: 8px;">Turn right at the information desk</li>
        <li>The return shelf is next to the librarian's counter</li>
      </ol>
    </div>

    <button id="at-return-shelf-button" style="margin-top: 15px;">I'm at the Return Shelf</button>
  `,i.appendChild(e),(t=e.querySelector("#return-navigation-back"))==null||t.addEventListener("click",()=>{a("return-books-screen")}),(s=e.querySelector("#at-return-shelf-button"))==null||s.addEventListener("click",()=>{a("return-confirmation-screen")})}function x(i){var t;const e=document.createElement("div");e.id="borrow-confirmation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">Borrow Confirmation</div>
    </div>

    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
      <div style="font-size: 60px; margin-bottom: 20px;">✅</div>
      <h2 style="margin-bottom: 15px;">Book Borrowed Successfully</h2>
      <p style="margin-bottom: 10px;">Clean Code by Robert C. Martin</p>
      <p style="margin-bottom: 30px;">Due date: April 28, 2025</p>

      <button id="borrow-done-button">Done</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#borrow-done-button"))==null||t.addEventListener("click",()=>{a("home-screen"),d("Book borrowed successfully")})}function k(i){var t,s;const e=document.createElement("div");e.id="return-books-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="return-list-back">←</span>
      <div class="header-title">Return Book</div>
    </div>

    <div class="section-title">Borrowed Books</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Due: April 28, 2025</div>
      </div>
      <button class="button" id="return-book-button" style="width: auto;">Return</button>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">To Kill a Mockingbird</div>
        <div class="item-subtitle">Due: May 2, 2025</div>
      </div>
      <button class="button" style="width: auto;">Return</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#return-list-back"))==null||t.addEventListener("click",()=>{a("home-screen")}),(s=e.querySelector("#return-book-button"))==null||s.addEventListener("click",()=>{a("return-navigation-screen")})}function w(i){var t;const e=document.createElement("div");e.id="return-confirmation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">Return Confirmation</div>
    </div>

    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
      <div style="font-size: 60px; margin-bottom: 20px;">✅</div>
      <h2 style="margin-bottom: 15px;">Book Returned Successfully</h2>
      <p style="margin-bottom: 30px;">Clean Code by Robert C. Martin</p>

      <button id="return-done-button">Done</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#return-done-button"))==null||t.addEventListener("click",()=>{a("home-screen"),d("Book returned successfully")})}function S(i){var t,s,o;const e=document.createElement("div");e.id="profile-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">My Profile</div>
    </div>

    <div class="user-info">
      <h2>Rama Kurniawan</h2>
      <p>ID: RAMA1703</p>
      <p>Email: rama.k@campus.edu</p>
    </div>

    <div class="section-title">Borrowed Books</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Due: 28 Apr 2025</div>
      </div>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">To Kill a Mockingbird</div>
        <div class="item-subtitle">Due: 2 May 2025</div>
      </div>
    </div>

    <button id="logout-button">Logout</button>

    <div class="bottom-nav">
      <div class="nav-item" id="nav-home-profile">
        <span class="nav-icon">🏠</span>
        Home
      </div>
      <div class="nav-item" id="nav-search-profile">
        <span class="nav-icon">🔍</span>
        Search
      </div>
      <div class="nav-item active" id="nav-profile-profile">
        <span class="nav-icon">👤</span>
        Profile
      </div>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#logout-button"))==null||t.addEventListener("click",()=>{a("login-screen")}),(s=e.querySelector("#nav-home-profile"))==null||s.addEventListener("click",()=>{a("home-screen")}),(o=e.querySelector("#nav-search-profile"))==null||o.addEventListener("click",()=>{a("search-results-screen")})}
