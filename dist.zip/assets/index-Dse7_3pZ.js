(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const o of r)if(o.type==="childList")for(const n of o.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(r){const o={};return r.integrity&&(o.integrity=r.integrity),r.referrerPolicy&&(o.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?o.credentials="include":r.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function s(r){if(r.ep)return;r.ep=!0;const o=t(r);fetch(r.href,o)}})();document.addEventListener("DOMContentLoaded",()=>{const i=document.getElementById("app");if(!i)return;const e=document.createElement("div");e.className="wireframe-container",i.appendChild(e);const t=document.createElement("div");t.className="toast",i.appendChild(t),u(e),m(e),p(e),b(e),h(e),f(e),y(e),k(e),g(e),S(e),x(e),L(e),a("login-screen")});function a(i){document.querySelectorAll(".screen").forEach(s=>{s.classList.remove("active")});const t=document.getElementById(i);if(t){t.classList.add("active");const s=document.querySelector(".bottom-nav");if(s){const r=["home-screen","search-results-screen","profile-screen"].includes(i);if(s.classList.toggle("hidden",!r),r){document.querySelectorAll(".nav-item").forEach(l=>l.classList.remove("active"));let n="";i==="home-screen"?n="nav-home":i==="search-results-screen"?n="nav-search":i==="profile-screen"&&(n="nav-profile");const c=document.getElementById(n);c&&c.classList.add("active")}}}}function d(i){const e=document.querySelector(".toast");e&&(e.textContent=i,e.classList.add("active"),setTimeout(()=>{e.classList.remove("active")},3e3))}function u(i){const e=document.createElement("div");e.id="login-screen",e.className="screen",e.innerHTML=`
    <div style="flex: 1; display: flex; flex-direction: column; justify-content: center;">
      <h1 style="text-align: center; margin-bottom: 30px; font-size: 24px;">AFINDLY</h1>

      <div class="input-group">
        <label for="user-id">ID</label>
        <input type="text" id="user-id" placeholder="Enter your ID">
      </div>

      <div class="input-group">
        <label for="password">Password</label>
        <input type="password" id="password" placeholder="Enter your password">
      </div>

      <div class="error-message" id="login-error">Invalid ID or password. Please try again.</div>

      <button id="login-button">Login</button>
    </div>
  `,i.appendChild(e);const t=e.querySelector("#login-button");t==null||t.addEventListener("click",()=>{var o,n;const s=(o=e.querySelector("#user-id"))==null?void 0:o.value,r=(n=e.querySelector("#password"))==null?void 0:n.value;if(s&&r)a("home-screen"),d("Login successful");else{const c=e.querySelector("#login-error");c==null||c.classList.add("active"),setTimeout(()=>{c==null||c.classList.remove("active")},3e3)}})}function m(i){var s,r,o,n,c,l;const e=document.createElement("div");e.id="home-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">AFINDLY</div>
    </div>

    <div class="search-bar">
      <input type="text" placeholder="Search books...">
      <button id="search-button">🔍</button>
    </div>

    <div class="quick-actions">
      <div class="button" id="borrow-button">Borrow Book</div>
      <div class="button" id="return-button">Return Book</div>
      <div class="button" id="profile-button">My Profile</div>
    </div>

    <div class="section-title">Recently Searched</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">The Great Gatsby</div>
        <div class="item-subtitle">F. Scott Fitzgerald</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">To Kill a Mockingbird</div>
        <div class="item-subtitle">Harper Lee</div>
      </div>
      <span class="badge unavailable">Borrowed</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">1984</div>
        <div class="item-subtitle">George Orwell</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="bottom-nav">
      <div class="nav-item active" id="nav-home">Home</div>
      <div class="nav-item" id="nav-search">Search</div>
      <div class="nav-item" id="nav-profile">Profile</div>
    </div>
  `,i.appendChild(e),(s=e.querySelector("#search-button"))==null||s.addEventListener("click",()=>{a("search-results-screen")}),(r=e.querySelector("#borrow-button"))==null||r.addEventListener("click",()=>{a("search-results-screen")}),(o=e.querySelector("#return-button"))==null||o.addEventListener("click",()=>{a("return-books-screen")}),(n=e.querySelector("#profile-button"))==null||n.addEventListener("click",()=>{a("profile-screen")}),(c=e.querySelector("#nav-search"))==null||c.addEventListener("click",()=>{a("search-results-screen")}),(l=e.querySelector("#nav-profile"))==null||l.addEventListener("click",()=>{a("profile-screen")}),e.querySelectorAll(".list-item").forEach(v=>{v.addEventListener("click",()=>{a("book-details-screen")})})}function p(i){var s,r,o;const e=document.createElement("div");e.id="search-results-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="search-back">←</span>
      <div class="header-title">Search Results</div>
    </div>

    <div class="search-bar">
      <input type="text" placeholder="Search books..." value="programming">
      <button>🔍</button>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Robert C. Martin</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">The Pragmatic Programmer</div>
        <div class="item-subtitle">Andrew Hunt, David Thomas</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Design Patterns</div>
        <div class="item-subtitle">Erich Gamma, et al.</div>
      </div>
      <span class="badge unavailable">Borrowed</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Refactoring</div>
        <div class="item-subtitle">Martin Fowler</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">JavaScript: The Good Parts</div>
        <div class="item-subtitle">Douglas Crockford</div>
      </div>
      <span class="badge available">Available</span>
    </div>

    <div class="bottom-nav">
      <div class="nav-item" id="nav-home-search">Home</div>
      <div class="nav-item active" id="nav-search-search">Search</div>
      <div class="nav-item" id="nav-profile-search">Profile</div>
    </div>
  `,i.appendChild(e),(s=e.querySelector("#search-back"))==null||s.addEventListener("click",()=>{a("home-screen")}),(r=e.querySelector("#nav-home-search"))==null||r.addEventListener("click",()=>{a("home-screen")}),(o=e.querySelector("#nav-profile-search"))==null||o.addEventListener("click",()=>{a("profile-screen")}),e.querySelectorAll(".list-item").forEach(n=>{n.addEventListener("click",()=>{a("book-details-screen")})})}function b(i){var t,s;const e=document.createElement("div");e.id="book-details-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="details-back">←</span>
      <div class="header-title">Book Details</div>
    </div>

    <h2 style="margin-bottom: 5px;">Clean Code</h2>
    <p style="color: var(--secondary-color); margin-bottom: 15px;">Robert C. Martin</p>

    <div style="border: 1px solid var(--border-color); width: 120px; height: 180px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: var(--secondary-color);">
      Book Cover
    </div>

    <p style="margin-bottom: 20px;">
      A handbook of agile software craftsmanship that helps programmers write clean, maintainable code.
    </p>

    <div class="section-title">Location</div>
    <p>Floor: 3</p>
    <p>Shelf: CS-101</p>

    <div class="map-container">
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: var(--secondary-color);">
        Floor Map
      </div>
      <div class="map-marker" style="top: 75px; left: 150px;"></div>
    </div>

    <div class="action-buttons">
      <button id="borrow-this-book">Borrow</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#details-back"))==null||t.addEventListener("click",()=>{a("search-results-screen")}),(s=e.querySelector("#borrow-this-book"))==null||s.addEventListener("click",()=>{a("borrow-scan-floor-screen")})}function h(i){var t,s;const e=document.createElement("div");e.id="borrow-scan-floor-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="scan-floor-back">←</span>
      <div class="header-title">Scan Floor QR Code</div>
    </div>

    <div class="scanner-overlay">
      <div class="scanner-frame"></div>
      <div class="scanner-text">Align the QR code for Floor 3 within the frame to verify your location</div>
      <button id="simulate-floor-scan" style="width: auto; margin-top: 20px;">Simulate Successful Scan</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#scan-floor-back"))==null||t.addEventListener("click",()=>{a("book-details-screen")}),(s=e.querySelector("#simulate-floor-scan"))==null||s.addEventListener("click",()=>{a("borrow-navigation-screen")})}function f(i){var t,s;const e=document.createElement("div");e.id="borrow-navigation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="navigation-back">←</span>
      <div class="header-title">Navigate to Book</div>
    </div>

    <div style="text-align: center; margin-bottom: 20px;">
      <h2>Clean Code</h2>
      <p>Floor: 3, Shelf: CS-101</p>
    </div>

    <div class="map-container" style="height: 300px;">
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: var(--secondary-color);">
        Floor Map
      </div>

      <!-- You are here marker -->
      <div class="map-marker" style="top: 150px; left: 50px; background-color: blue;"></div>

      <!-- Book location marker -->
      <div class="map-marker" style="top: 75px; left: 250px;"></div>

      <!-- Path between markers -->
      <div class="map-path" style="top: 150px; left: 50px; width: 100px; transform: rotate(-45deg); transform-origin: left;"></div>
      <div class="map-path" style="top: 75px; left: 150px; width: 100px;"></div>
    </div>

    <p style="text-align: center; margin: 15px 0;">Follow the path to find the book</p>

    <button id="found-book-button">I Found the Book</button>
  `,i.appendChild(e),(t=e.querySelector("#navigation-back"))==null||t.addEventListener("click",()=>{a("borrow-scan-floor-screen")}),(s=e.querySelector("#found-book-button"))==null||s.addEventListener("click",()=>{a("borrow-scan-book-screen")})}function y(i){var t,s;const e=document.createElement("div");e.id="borrow-scan-book-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="scan-book-back">←</span>
      <div class="header-title">Scan Book Barcode</div>
    </div>

    <div class="scanner-overlay">
      <div class="scanner-frame"></div>
      <div class="scanner-text">Align the barcode on the back of the book within the frame to verify</div>
      <button id="simulate-book-scan" style="width: auto; margin-top: 20px;">Simulate Successful Scan</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#scan-book-back"))==null||t.addEventListener("click",()=>{a("borrow-navigation-screen")}),(s=e.querySelector("#simulate-book-scan"))==null||s.addEventListener("click",()=>{a("borrow-confirmation-screen")})}function k(i){var t;const e=document.createElement("div");e.id="borrow-confirmation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">Borrow Confirmation</div>
    </div>

    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
      <div style="font-size: 60px; margin-bottom: 20px;">✅</div>
      <h2 style="margin-bottom: 15px;">Book Borrowed Successfully</h2>
      <p style="margin-bottom: 10px;">Clean Code by Robert C. Martin</p>
      <p style="margin-bottom: 30px;">Due date: April 28, 2025</p>

      <button id="borrow-done-button">Done</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#borrow-done-button"))==null||t.addEventListener("click",()=>{a("home-screen"),d("Book borrowed successfully")})}function g(i){var t,s;const e=document.createElement("div");e.id="return-books-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="return-list-back">←</span>
      <div class="header-title">Return Book</div>
    </div>

    <div class="section-title">Borrowed Books</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Due: April 28, 2025</div>
      </div>
      <button class="button" id="return-book-button" style="width: auto;">Return</button>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">To Kill a Mockingbird</div>
        <div class="item-subtitle">Due: May 2, 2025</div>
      </div>
      <button class="button" style="width: auto;">Return</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#return-list-back"))==null||t.addEventListener("click",()=>{a("home-screen")}),(s=e.querySelector("#return-book-button"))==null||s.addEventListener("click",()=>{a("return-navigation-screen")})}function S(i){var t,s;const e=document.createElement("div");e.id="return-navigation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <span class="back-button" id="return-navigation-back">←</span>
      <div class="header-title">Navigate to Return Shelf</div>
    </div>

    <div style="text-align: center; margin-bottom: 20px;">
      <h2>Return Book</h2>
      <p>Clean Code by Robert C. Martin</p>
      <p>Go to Return Shelf on Floor 2</p>
    </div>

    <div class="map-container" style="height: 300px;">
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: var(--secondary-color);">
        Floor Map
      </div>

      <!-- You are here marker -->
      <div class="map-marker" style="top: 150px; left: 50px; background-color: blue;"></div>

      <!-- Return shelf marker -->
      <div class="map-marker" style="top: 100px; left: 200px;"></div>

      <!-- Path between markers -->
      <div class="map-path" style="top: 150px; left: 50px; width: 50px; transform: rotate(-45deg); transform-origin: left;"></div>
      <div class="map-path" style="top: 100px; left: 100px; width: 100px;"></div>
    </div>

    <p style="text-align: center; margin: 15px 0;">Follow the path to the return shelf</p>

    <button id="at-return-shelf-button">I'm at the Return Shelf</button>
  `,i.appendChild(e),(t=e.querySelector("#return-navigation-back"))==null||t.addEventListener("click",()=>{a("return-books-screen")}),(s=e.querySelector("#at-return-shelf-button"))==null||s.addEventListener("click",()=>{a("return-confirmation-screen")})}function x(i){var t;const e=document.createElement("div");e.id="return-confirmation-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">Return Confirmation</div>
    </div>

    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
      <div style="font-size: 60px; margin-bottom: 20px;">✅</div>
      <h2 style="margin-bottom: 15px;">Book Returned Successfully</h2>
      <p style="margin-bottom: 30px;">Clean Code by Robert C. Martin</p>

      <button id="return-done-button">Done</button>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#return-done-button"))==null||t.addEventListener("click",()=>{a("home-screen"),d("Book returned successfully")})}function L(i){var t,s,r;const e=document.createElement("div");e.id="profile-screen",e.className="screen",e.innerHTML=`
    <div class="header">
      <div class="header-title">My Profile</div>
    </div>

    <div class="user-info">
      <h2>John Doe</h2>
      <p>ID: JD1234</p>
      <p>Email: john.doe@example.com</p>
    </div>

    <div class="section-title">Borrowed Books</div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">Clean Code</div>
        <div class="item-subtitle">Due: April 28, 2025</div>
      </div>
    </div>

    <div class="list-item">
      <div class="item-details">
        <div class="item-title">To Kill a Mockingbird</div>
        <div class="item-subtitle">Due: May 2, 2025</div>
      </div>
    </div>

    <button id="logout-button" style="margin-top: auto;">Logout</button>

    <div class="bottom-nav">
      <div class="nav-item" id="nav-home-profile">Home</div>
      <div class="nav-item" id="nav-search-profile">Search</div>
      <div class="nav-item active" id="nav-profile-profile">Profile</div>
    </div>
  `,i.appendChild(e),(t=e.querySelector("#logout-button"))==null||t.addEventListener("click",()=>{a("login-screen")}),(s=e.querySelector("#nav-home-profile"))==null||s.addEventListener("click",()=>{a("home-screen")}),(r=e.querySelector("#nav-search-profile"))==null||r.addEventListener("click",()=>{a("search-results-screen")})}
